from playwright.sync_api import Page

from topMarket_project.pages.base_page import BasePage


class SingInPage(BasePage):

    def __init__(self, page:Page):
        super().__init__(page)

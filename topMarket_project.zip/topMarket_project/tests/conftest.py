

import pytest
from playwright.sync_api import Page

from topMarket_project.pages.cart_page import CartPage
from topMarket_project.pages.checkOut_page import CheckOutPage
from topMarket_project.pages.item_page import ItemPage
from topMarket_project.pages.main_page import MainPage
from topMarket_project.pages.order_page import OrderPage
from topMarket_project.pages.register_page import RegisterPage
from topMarket_project.pages.search_page import SearchPage
from topMarket_project.pages.singIn_page import SingInPage
from topMarket_project.pages.terms_condition_page import TermsAndConditionPage
from topMarket_project.pages.wishlist_page import WishlistPage



@pytest.fixture(scope="class")     #autouse=True
def setup_page_class(request, browser):
    page = browser.new_page()
    page.goto("https://www.topmarket.co.il/en/")
    request.cls.cart_page = CartPage(page)
    request.cls.item_page = ItemPage(page)
    request.cls.main_page = MainPage(page)
    request.cls.register_page = RegisterPage(page)
    request.cls.search_page = SearchPage(page)
    request.cls.singIn_page = SingInPage(page)
    request.cls.terms_condition_page = TermsAndConditionPage(page)
    request.cls.wishlist_page = WishlistPage(page)
    request.cls.checkOut_Page = CheckOutPage(page)
    request.cls.order_page = OrderPage(page)


    yield
    page.close()



@pytest.fixture(scope="function" )   #autouse=True
def setup_page_function(request, page: Page):
    page.goto("https://www.topmarket.co.il/en/")
    request.cls.cart_page = CartPage(page)
    request.cls.item_page = ItemPage(page)
    request.cls.main_page = MainPage(page)
    request.cls.register_page = RegisterPage(page)
    request.cls.search_page = SearchPage(page)
    request.cls.singIn_page = SingInPage(page)
    request.cls.terms_condition_page = TermsAndConditionPage(page)
    request.cls.wishlist_page = WishlistPage(page)
    request.cls.checkOut_Page = CheckOutPage(page)
    request.cls.order_page = OrderPage(page)
    yield
    page.close()


